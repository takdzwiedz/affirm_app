<h4>Super! Gwarantuję Ci wspaniałą przygodę. Zobaczysz!</h4>
<p>
    Teraz tylko potwierdź swoją rejestrację klikając na link z mejla, którego Ci wysłałem i zaczynamy!<br> 
    Podekscytowany? Ja cholernie!<br>
    Dobrego,<br>
    Artur
</p>