"MOGĘ - AFFIRMATION APP"
VERSION: 1.0
RELEASE DATE: 09-06.2017

author: Artur Kacprzak

Brief description: This is the application that sends affirmations to registered users.

I. Database

1. Affirmations

List of affirmations


2. Users

List of users

II. Displays

II.A User

1. Welcome


About the author
About the idea
How it works
Registration

2. Confirmation page

II.B Admin

1. List of affirmations

(affirmation_id, affirmation, author, date_of_release, comments, rating)

2. List of users

Total number of users

(user_id, e-mail, date_of_registration)


